using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RULETA : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("rotation.z: " + gameObject.transform.rotation.z);
        Debug.Log("eulerAngles.z: " + gameObject.transform.rotation.eulerAngles.z);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
