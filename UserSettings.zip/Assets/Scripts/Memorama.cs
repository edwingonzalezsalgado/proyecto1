using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Memorama : MonoBehaviour
{    
    public Sprite[] imagenes;
    public Image[] posiciones;
    public Sprite reverso;

    private string card1;
    private int indexCard1;
    private string card2;
    private int indexCard2;  

    public void FlipCard (int index) 
    {
        if(card1 == null)
        {
            card1 = imagenes[index].name;
            posiciones[index].sprite = imagenes[index];
            indexCard1 = index;
        }
        else if(card2 == null)
        {
            card2 = imagenes[index].name;
            posiciones[index].sprite = imagenes[index];
            indexCard2 = index;
        }else
        {
            Consola("seleccion realizada, verifica");
        }        
    }

    public void CheckSelection () 
    {
        if(card1 == card2) 
        {
            Consola("exito");
            card1 = null;
            card2 = null;
            indexCard1 = 0;
            indexCard2 = 0;
        }   
        else
        {
            Consola("no son iguales");
            posiciones[indexCard1].sprite = reverso;
            posiciones[indexCard2].sprite = reverso;
            card1 = null;
            card2 = null;
            indexCard1 = 0;
            indexCard2 = 0;
        }
    }

    private void Consola(string msj)
    {
        Debug.Log(msj);
    }

    public void Restart()
    {
        SceneManager.LoadScene(0);        
    }
    public void Exit()
    {
        Consola("salir");
        Application.Quit();   
    }
}
