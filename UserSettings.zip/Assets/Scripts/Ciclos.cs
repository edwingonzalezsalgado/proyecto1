using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ciclos : MonoBehaviour
{
     public string[] arrNombres = {"edwin", "profe", "compañeros", "ucamp"};
     
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Ejemplo foreach: ");
        foreach(string nombre in arrNombres) {
            Debug.Log("jugador: " + nombre);
        }
        Debug.Log("-------------------------------------------------");


        Debug.Log("Ejercicio 1: ");
        int numRandom = getRandomNumber();
        Debug.Log("Valor random: " + numRandom.ToString());
        Debug.Log("Recursos aumentados a: " + RecolectResources(numRandom).ToString());

        Debug.Log("-------------------------------------------------");


        Debug.Log("Ejercicio 2: ");
        int acumula = 0;

        for(int veces = 0;veces<16;veces++)
        {
            if(acumula==0)
                acumula = acumula + 1;
            else
                acumula = acumula + acumula;
        }
        Debug.Log("Valor acumulado: " + acumula.ToString());

        Debug.Log("-------------------------------------------------");


        Debug.Log("Ejercicio 3: ");

        for(int veces = 1;veces<=10;veces++)
        {
            double numPow = (double)Mathf.Pow(veces, veces);
            Debug.Log("NIVEL " + veces.ToString() + " elevado a la "+veces.ToString()+" es igual a => " + numPow.ToString());
        }

        Debug.Log("-------------------------------------------------");


        Debug.Log("Ejercicio 4 y 5: ");
        int[] arrNumeros = {6, 7,7,5,3,9,10,11};
        int numN = 7;
        int seRepite = 0;
        int esMayor = 0;
        
        for(int posicion = 0;posicion<arrNumeros.Length;posicion++)
        {        
            if(arrNumeros[posicion]==numN)
            {
                seRepite++;
            }

            if(arrNumeros[posicion]>numN)
            {
                esMayor++;
            }

        }
        Debug.Log("Num N es: " + numN.ToString() +" y se repite "+seRepite.ToString()+" veces");
        Debug.Log("Num N es: " + numN.ToString() +" y hay "+esMayor.ToString()+" numeros mayores");

        Debug.Log("-------------------------------------------------");


        Debug.Log("otro ejemplo: ");
        
        int numEjemplo = 7;
        Debug.Log("1numEjemplo N es: " + numEjemplo.ToString() );
        Debug.Log("2numEjemplo N es: " + (numEjemplo++).ToString() );
        Debug.Log("3numEjemplo N es: " + numEjemplo.ToString() );



    }

    // Update is called once per frame
    void Update()
    {
        
    }


    int RecolectResources(int gold)
    {
        int acumula = 0;

        for(int cantidad = 0;cantidad<gold;cantidad++)
        {
         acumula = acumula + ((cantidad +1)*10);
        }
        
        return acumula;
    }

    int getRandomNumber()
    {        
        return Random.Range(1, 10);
    }
}
