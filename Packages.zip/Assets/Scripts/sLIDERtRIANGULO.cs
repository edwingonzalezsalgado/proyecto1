using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class sLIDERtRIANGULO : MonoBehaviour
{
    public Slider sliderX;
    public Slider sliderY;
    public Slider sliderZ;

    //public Transform from;
    //public Transform to;
    //private float timeCount = 0.0f;

    public void button_onclick () {
        gameObject.transform.position = new Vector3(5,0,0);
    }

    public void MueveEnX () {

        Debug.Log("Fire X");
        Debug.Log(sliderX.value);
        gameObject.transform.position = new Vector3(sliderX.value,sliderY.value,0);
        
    }
    public void MueveEnY () {

        Debug.Log("Fire Y");
        Debug.Log(sliderY.value);
        gameObject.transform.position = new Vector3(sliderX.value,sliderY.value,0);
        
    }
    public void Rotar()
    {
        float smooth = 50.0f;
        float tiltAngle = 400.0f;


        // Smoothly tilts a transform towards a target rotation.
        //float tiltAroundZ = Input.GetAxis("Horizontal") * tiltAngle;
        //float tiltAroundX = Input.GetAxis("Vertical") * tiltAngle;

        float tiltAroundZ = sliderZ.value * tiltAngle;
        float tiltAroundX = sliderX.value * tiltAngle;




        Debug.Log("tiltAroundZ "+tiltAroundZ);
        Debug.Log("-------------------");
        Debug.Log("tiltAroundX "+tiltAroundX);
        Debug.Log("-------------------");
        // Rotate the cube by converting the angles into a quaternion.
        Quaternion target = Quaternion.Euler(tiltAroundX, 0, tiltAroundZ);

        // Dampen towards the target rotation
        //transform.rotation = Quaternion.Slerp(transform.rotation, target,  Time.deltaTime * smooth);

        Debug.Log("Rotar Z"+sliderZ.value);
        Debug.Log("-------------------");
        Debug.Log("Time.deltaTime:"+Time.deltaTime);
        Debug.Log("-------------------");
        
        gameObject.transform.rotation = Quaternion.Slerp(gameObject.transform.rotation, target,  Time.deltaTime * smooth);
        //timeCount = timeCount + Time.deltaTime;
        //transform.rotation = Quaternion.Slerp(from.rotation, to.rotation, timeCount);
        
        //gameObject.transform.Rotate(new Vector3(sliderX.value,sliderY.value,sliderZ.value));
    }
    




}
