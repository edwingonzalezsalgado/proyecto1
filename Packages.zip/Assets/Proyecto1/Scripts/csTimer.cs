using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class csTimer : MonoBehaviour
{
    #region Atributos de la Clase publicos

    public TextMeshProUGUI lblTimer;    

    #endregion

    #region Eventos de la Clase
    // Start is called before the first frame update
    void Start()
    {
        
    }
    #endregion
    // Update is called once per frame
    void Update()
    {
        
            StartCoroutine(ExampleCoroutine());
        
    }

    IEnumerator ExampleCoroutine()
    {
        do
        {
            string tiempo = ((int)Time.timeSinceLevelLoad).ToString();
            lblTimer.text = "Tiempo transcurrido: " + tiempo;

            msj("1 time: " + tiempo);
            yield return new WaitForSeconds(1);            
        } while (true);

        
    }

    #region Funciones de la Clase
    /// <summary>
    /// Funcion para mostrar mensajes en consola
    /// </summary>
    /// <param name="msj">mensaje a mostrar</param>
    private void msj(string msj)
    {
        //Debug.Log(msj);
    }
    #endregion

}
