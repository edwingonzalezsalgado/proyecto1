using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Condicional : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        int valorGolpe = getRandomNumber();
        Debug.Log("valor inicial: " + valorGolpe.ToString());
                
        if(valorGolpe == 3)
        {
            Debug.Log("ZAZ ATAQUE CRITICO: " + valorGolpe.ToString());
        }

        bool esPar = valorGolpe %2==0;

        if(esPar)        
            Debug.Log("El golpe fue PAR: " + valorGolpe.ToString());        
        else
            Debug.Log("El golpe fue IMPAR: " + valorGolpe.ToString());
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    int getRandomNumber()
    {        
        return Random.Range(1, 3);
    }
}
