using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
public class csFin : MonoBehaviour
{
    public TextMeshProUGUI lblPuntaje;
    // Start is called before the first frame update
    void Start()
    {
        int contadorPuntos = PlayerPrefs.GetInt("contadorPuntos");
        lblPuntaje.text = "Puntos: " + contadorPuntos.ToString();
    }
    public void Restart()
    {
        SceneManager.LoadScene(0);
    }
    public void Exit()
    {
        Application.Quit();
    }
}
