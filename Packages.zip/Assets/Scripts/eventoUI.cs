using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class eventoUI : MonoBehaviour
{
    public string nombreTeclota;

    public void ImprimeNombreTeclota () {
        Debug.Log(nombreTeclota);
    }
}
