using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class csAwake : MonoBehaviour
{
    public string _name;
    public int _vida;
    public int _fuerza;
    public int _defensa;
    public int _limiteCarga;
    public int _energia;
    public float _posicionX;
    public bool _direccion;
    public float _speed;
    public csAwake() {
        Debug.Log("constructor de la clase csAwake");
        _name = "coki";
        _vida = 1000;
        _fuerza = 1000;
        _defensa = 1000;
        _limiteCarga = 100;
        _energia = 0;
        _posicionX = 0.0f;
        _direccion = true;
        _speed = 1.0f;
    }

    void Awake()
    {
        Debug.Log("Awake");
        Debug.Log("Nombre: "+_name);
        Debug.Log("Vida: "+_vida.ToString());
        Debug.Log("Fuerza: "+_fuerza.ToString());
        Debug.Log("Defensa: "+_defensa.ToString());
    }
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Start");
    }

    // Update is called once per frame
    void Update()
    {
        if(_energia != _limiteCarga)
        {
            cargaEnergia();
        }
        else{
            //Debug.Log("full energy al: "+_energia.ToString());
        }

       //yield on a new YieldInstruction that waits for 5 seconds.
        //new WaitForSeconds(1);
        
    }
     void cargaEnergia()
    {        
        _energia++;
        Debug.Log("se aumento energia a: "+_energia.ToString());
    }


    void LateUpdate()
    {
         if(_posicionX > 10)
        {
            _direccion = false;
        }
         if(_posicionX < 0)
        {
            _direccion = true;
        }

        switch (_direccion)
        {
            case true://adelante
            {
                avanzaObjeto();
                break;
            }
            case false://atras
            {
                regresaObjeto();
                break;
            }
        }

        //new WaitForSeconds(1);
    }
   


    void avanzaObjeto()
    {        
        _posicionX = _posicionX + (0.01f * _speed);
        //gameObject.transform.position = new Vector3(gameObject.transform.position.x+(1*Time.deltaTime*_speed),0,0);
        gameObject.transform.position = new Vector3(_posicionX,0,0);
        Debug.Log("AVANZA _posicionX: "+_posicionX.ToString());
    }

    void regresaObjeto()
    {        
        _posicionX = _posicionX - (0.01f * _speed);
        //gameObject.transform.position = new Vector3(gameObject.transform.position.x-(1*Time.deltaTime*_speed),0,0);
        gameObject.transform.position = new Vector3(_posicionX,0,0);
        Debug.Log("REGRESA _posicionX: "+_posicionX.ToString());
    }



}
