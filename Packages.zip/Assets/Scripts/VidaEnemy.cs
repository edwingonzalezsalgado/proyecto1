using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class VidaEnemy : MonoBehaviour
{
    public TextMeshProUGUI lblVida; 
    public int vidas;
    // Start is called before the first frame update
    void Start()
    {
        lblVida.text = "Vidas: "+vidas;
    }

    private void OnCollisionEnter2D(Collision2D other) {
        Debug.Log(""+other.gameObject.name);
        vidas--;
        lblVida.text = "Vidas: "+vidas;

        if(vidas<10)
        {
            gameObject.GetComponent<SpriteRenderer>().color = Color.yellow;
        }
        if(vidas<5)
        {
            gameObject.GetComponent<SpriteRenderer>().color = Color.red;
        }

    }
}
