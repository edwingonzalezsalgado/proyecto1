using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DispararBala : MonoBehaviour
{
    public float power;

    private float ejeY = 1;
    private Vector3 posicionInicial;
    // Start is called before the first frame update
    void Start()
    {
        posicionInicial = gameObject.transform.position;
    }
private void Update() {
    if(Input.GetKeyDown(KeyCode.DownArrow))
    {
        ejeY -= 0.2f;
    }
    if(Input.GetKeyDown(KeyCode.UpArrow))
    {
        ejeY += 0.2f;
    }

}
    // Update is called once per frame
    public void Resset() {
        gameObject.transform.position = posicionInicial;
        gameObject.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
        gameObject.GetComponent<Rigidbody2D>().angularVelocity = 0;
        gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(1,ejeY)*power);
        Debug.Log("int-->   "+int.MinValue);
    }

    private void OnCollisionEnter2D(Collision2D other) {
        Resset();
    }
}
