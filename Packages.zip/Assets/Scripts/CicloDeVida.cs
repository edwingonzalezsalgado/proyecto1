using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CicloDeVida : MonoBehaviour
{
    public int EnemyHP;
    // Start is called before the first frame update
    void Start()
    {
        EnemyHP = 1000;
        Debug.Log("Vida inicial: " + EnemyHP.ToString());
    }

    // Update is called once per frame
    void Update()
    {/*
        QuitarVida();
        Debug.Log("Vida: " + EnemyHP.ToString());

        switch (EnemyHP)
        {
            case 0:
                {
                    ResetVida();
                    break;
                }
        }*/
    }

    void QuitarVida()
    {
        EnemyHP--;
        Debug.Log("PUMMM GOLPE!!!!: " + EnemyHP.ToString());        
    }

    void ResetVida()
    {
        EnemyHP = 1000;
        Debug.Log("Vida RESTAURADA: " + EnemyHP.ToString());
        Debug.Log("--------------------------- ");
    }

}
