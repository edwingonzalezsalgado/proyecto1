using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TEMPORIZADOR : MonoBehaviour
{
    public TextMeshProUGUI lblContador; 
    public float startTime;
    // Start is called before the first frame update
    void Start()
    {
        lblContador.text = startTime.ToString();
        startTime = Time.time + startTime;
    }

    // Update is called once per frame
    void Update()
    {
        if(startTime > 0)
        {
            startTime -= Time.deltaTime;
            lblContador.text = startTime.ToString("0.0");
        }
    }
}
