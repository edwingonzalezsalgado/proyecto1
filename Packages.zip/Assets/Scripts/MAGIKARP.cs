using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class MAGIKARP : MonoBehaviour
{
    public float jumpFuerza;
    public Slider forceSliderIndicator;
    public TEMPORIZADOR tempReference;
    private float pressTime;
    private bool ispressTime;
    //private bool active = false;
    //public TextMeshProUGUI lblPressure;   
    //public TextMeshProUGUI lblDeltaPosition;   
    private float timePressCount;
    // Update is called once per frame
    void Update()
    {
        if(Input.GetButtonDown("Jump"))
        {
            timePressCount = Time.time;
            
            ispressTime = true;
        }
        if(ispressTime)
        {
            pressTime = Time.time - timePressCount;

            if(pressTime > 1)
            {
                pressTime = 1;
            }
        }

        forceSliderIndicator.value = pressTime;

        //if(Input.GetKeyDown(KeyCode.Space) || Input.GetKey(KeyCode.UpArrow))
        //if(Input.GetButtonDown("Jump")&&active)//para evitar q salte varias veces
        if(Input.GetButtonUp("Jump") && tempReference.startTime > 0)
        {            
            Debug.Log("boton soltado");
            //gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0,1));
            //gameObject.GetComponent<Rigidbody2D>().AddForce(Vector2.up*jumpFuerza);
            gameObject.GetComponent<Rigidbody2D>().AddForce(Vector2.up * jumpFuerza * pressTime);
            //active = false; 
            pressTime = 0;
            ispressTime = false;           
        }
        
        /*if(Input.GetTouch(0).phase != TouchPhase.Ended)//touch del cel
        {
            gameObject.GetComponent<Rigidbody2D>().AddForce(Vector2.up*jumpFuerza);
        } */       

    }

    private void OnCollisionEnter2D(Collision2D other) {
        if(other.gameObject.name == "piso")
        {
            //active = true;
        }
    }
}
