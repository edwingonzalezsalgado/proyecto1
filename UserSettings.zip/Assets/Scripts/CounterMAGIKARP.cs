using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CounterMAGIKARP : MonoBehaviour
{
    private int counter = 0;
    public TextMeshProUGUI lblContador;   
    public TEMPORIZADOR timeReference;
    private void Update() {
        //if(timeReference.startTime < 0)
        //{            
            Debug.Log("counter: " + counter.ToString());
            Debug.Log("timeReference.startTime: " + timeReference.startTime.ToString());
            //timeReference.startTime = 0;
        //}
    }
    private void OnTriggerEnter2D(Collider2D other) {

        if(other.tag == "Player")
        {
            counter++;
            lblContador.text = counter.ToString();
            Debug.Log("counter: " + counter.ToString());
        }
    }
}
