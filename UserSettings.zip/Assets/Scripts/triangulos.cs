using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class triangulos : MonoBehaviour
{
    public int[] trianguloEquilatero = {60,60,60};
    public int[] trianguloIsosceles = {40,70,70};
    public int[] trianguloEscaleno = {59,31,90};

    //
    // Start is called before the first frame update
    void Start()
    {
       Debug.Log("triangulos gameObject");
        gameObject.transform.position = new Vector3(-7,1,0);

        Debug.Log("validando triangulos ");
        
        
        validateTriangulo(trianguloEscaleno);
        validateTriangulo(trianguloEquilatero);
        validateTriangulo(trianguloIsosceles);
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    string validateTriangulo(int[] triangulo)
    {
        //equilatero
        if(triangulo[0] == triangulo[1] && triangulo[0] == triangulo[2] )
        {
            Debug.Log("es un triangulo equilatero");
            return "equilatero";
        }
        else if(triangulo[0] != triangulo[1] && triangulo[0] != triangulo[2]&& triangulo[1] != triangulo[2] )//escaleno
        {
            Debug.Log("es un triangulo escaleno");
            return "escaleno";
        }
        else{
            Debug.Log("es un triangulo isosceles");
            return "isosceles";
        }

    }
}
