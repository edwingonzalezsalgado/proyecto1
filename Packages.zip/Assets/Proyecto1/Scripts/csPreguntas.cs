using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
using System;

public class csPreguntas : MonoBehaviour
{   
    #region Atributos de la Clase publicos

    public TextMeshProUGUI lblPregunta;
    public TextMeshProUGUI lblNumeroPregunta;
    public TextMeshProUGUI lblPuntos;   
    public Button  btnRespuesta1;  
    public Button  btnRespuesta2;
    public Button  btnRespuesta3;
    public Button  btnRespuesta4;
    public TextMeshProUGUI Text1;
    public TextMeshProUGUI Text2;
    public TextMeshProUGUI Text3;
    public TextMeshProUGUI Text4;    
    private string preguntasQueYaSalieron;
    private string respuestasQueYaSalieron;
    private int contadorPuntos = 0;
    private int contadorPreguntas = 0;

    #endregion

    #region Constructores de la Clase
    /// <summary>
    /// Constructor por default de la clase csPreguntas
    /// </summary>
    public csPreguntas()
    {
        respuestasQueYaSalieron = string.Empty;
        preguntasQueYaSalieron = string.Empty;
    }
    #endregion

    #region Eventos de la Clase
    // Evento Start is called before the first frame update
    void Start()
    {
        BuildInterfaz();
    }
    /// <summary>
    /// Evento cuando se presiona un boton
    /// </summary>
    /// <param name="btn">boton presionado</param>
    public void btn_onClick(Button btn)
    {   
        BloqueaActivaBotones(btnRespuesta1,false);
        BloqueaActivaBotones(btnRespuesta2,false);
        BloqueaActivaBotones(btnRespuesta3,false);
        BloqueaActivaBotones(btnRespuesta4,false);

        if(btn.tag == "correcta")
        {
            contadorPuntos = contadorPuntos + 100;
            lblPuntos.text = contadorPuntos.ToString();
        }

        msj("boton presionado: " + btn.name);
        ValidaBotones(btnRespuesta1,btn);
        ValidaBotones(btnRespuesta2,btn);
        ValidaBotones(btnRespuesta3,btn);
        ValidaBotones(btnRespuesta4,btn);    

        StartCoroutine(tiempoDeEspera(0.5f));        
    }
    #endregion
    
    #region Metodos de la clase
    /// <summary>
    /// Metodo para cargar las preguntas y respuestas de manera aleatoria
    /// </summary>
    private void BuildInterfaz()
    {
        if(preguntasQueYaSalieron.Length >= 9)//si ya salieron las 9 preguntas hay que finalizar el juego
        {
            PlayerPrefs.SetInt("contadorPuntos", contadorPuntos);
            ChangeScene("Fin");
        }
        else //el juego continua
        {
            try
            {
                string[] respuestas;

                validaLabelText(lblPregunta, out respuestas);
                validaButtonText(btnRespuesta1, Text1, respuestas);
                validaButtonText(btnRespuesta2, Text2, respuestas);
                validaButtonText(btnRespuesta3, Text3, respuestas);
                validaButtonText(btnRespuesta4, Text4, respuestas);
            }
            catch(Exception ex)
            {
                string msj = ex.Message;
            }
        }
    }
    
    private void validaLabelText(TextMeshProUGUI lbl, out string[] respuestas)
    {        
        respuestas = new string[4];
        bool listo = false;
        string pregunta = string.Empty;

        do
        {
            int pos = getRandomNumber(10);            

            msj("pos pregunta: " + pos.ToString());     

            if(!preguntasQueYaSalieron.Contains(pos.ToString()))//si ya salió esa pregunta
            {
                GetPreguntaYrespuestas(pos, out pregunta, out respuestas);  
                listo = true;
                lbl.text = pregunta;
                contadorPreguntas++;
                lblNumeroPregunta.text = "Numero de pregunta: " + contadorPreguntas.ToString() + "/9";
                //msj("lbl.text : "+lbl.text);
                preguntasQueYaSalieron += pos.ToString();                
            }
            else
            {
                //msj("buscando otra pregunta");
            }            
        } while (!listo);

        msj("preguntasQueYaSalieron: " + preguntasQueYaSalieron);
    }

    /// <summary>
    /// Metodo para cargar el texto en los botones y marcar cual va ser el boton con la respuesta correcta o incorrecta
    /// </summary>
    /// <param name="btn">Boton a marcar como correcto o no</param>
    /// <param name="txt">Texto donde irá la respuesta</param>
    /// <param name="respuestas">Arreglo con las respuestas a mostrar</param>
    private void validaButtonText(Button btn, TextMeshProUGUI txt, string[] respuestas)
    {        
        bool listo = false;
        
        do
        {
            int pos = getRandomNumber(5);            

            //msj("pos: " + pos.ToString());     

            if(!respuestasQueYaSalieron.Contains(pos.ToString()))//si ya salió esa respuesta
            {
                listo = true;
                txt.text = respuestas[pos-1];
                //msj("txt.text : "+txt.text);
                respuestasQueYaSalieron += pos.ToString();
                
                if(pos == 1)//correcta
                {
                    btn.tag = "correcta";                    
                }
                else//incorrecta
                {
                    btn.tag = "incorrecta";
                }
                //msj("btn.tag: " + btn.tag);
                
            }
            else
            {
                //msj("buscando otra vez");
            }            
        } while (!listo);
        //msj("respuestasQueYaSalieron: " + respuestasQueYaSalieron);
    }
    /// <summary>
    /// Valida si el boton tiene la respuesta correcta o incorrecta
    /// </summary>
    /// <param name="btn">boton a validar</param>
    private void ValidaBotones(Button btn, Button btnPresionado)
    {
        if(btn.tag == "correcta")
        {
            changeButtonColor(btn,Color.green);                        
        }
        else if((btn.tag == "incorrecta")&&(btn.name == btnPresionado.name))
        {
            changeButtonColor(btn,Color.red);
        }    
    }

    private void BloqueaActivaBotones(Button btn, bool valor)
    {
        btn.enabled = valor;
    }
    


    #endregion

    #region Funciones de la Clase
    /// <summary>
    /// Funcion para mostrar mensajes en consola
    /// </summary>
    /// <param name="msj">mensaje a mostrar</param>
    private void msj(string msj)
    {
        Debug.Log(msj);
    }
    /// <summary>
    /// Funcion para obtener un numero aleatorio
    /// </summary>
    /// <param name="limit">indica el numero maximo exclusivo</param>
    /// <returns></returns>
    private int getRandomNumber(int limit)
    {        
        int number = UnityEngine.Random.Range(1, limit);

        return number;
    }
    /// <summary>
    /// Funcion para obtener una pregunta y sus respuestas
    /// </summary>
    /// <param name="opcion">opcion de pregunta a obtener</param>
    /// <param name="pregunta">cadena de salida de preguntas</param>
    /// <param name="respuestas">arreglo de salida de respuestas</param>
    private void GetPreguntaYrespuestas(int opcion, out string pregunta, out string[] respuestas)
    {
        pregunta = string.Empty;
        respuestas = new string[4];

        switch(opcion)
        {
            case 1:
            {
                pregunta = "¿Cuándo comienza la primera guerra mundial? ";
                respuestas = new string[] {"1910", "1810", "1922","1897"};
                break;
            }
            case 2:
            {
                pregunta = "¿Cuál es la civilización más antigua del mundo? ";
                respuestas = new string[] {"mesopotamia", "los minions", "neandertales","los chinos"};
                break;
            }
            case 3:
            {
                pregunta = "¿Cuál es la última dinastía en China?";
                respuestas = new string[] {"dinastía Qing", "yakuza", "origami","chim cham pu"};
                break;
            }
            case 4:
            {
                pregunta = "¿Quién es el primer presidente de los Estados Unidos? ";
                respuestas = new string[] {"Washington ", "lincon", "bush","obama bin laden"};
                break;
            }
            case 5:
            {
                pregunta = "¿Dónde se llevan a cabo los primeros Juegos Olímpicos de Verano?";
                respuestas = new string[] {"Atenas", "italia", "egipto","india"};
                break;
            }
            case 6:
            {
                pregunta = "¿Cuál es la dinastía más antigua que sigue gobernando?";
                respuestas = new string[] {"Japón", "inglaterra", "mexico","korea"};
                break;
            }
            case 7:
            {
                pregunta = "¿De qué país se originó la civilización azteca? ";
                respuestas = new string[] {"México", "brasil", "argentina","honduras"};
                break;
            }
            case 8:
            {
                pregunta = "¿Quién exploró el Nuevo Mundo?";
                respuestas = new string[] {"Cristobal colon.", "ash ketchup", "maverick","google"};
                break;
            }
            case 9:
            {
                pregunta = "¿Dónde se encuentra Babilonia?";
                respuestas = new string[] {"Irak", "polonia", "vietnam","ucrania"};
                break;
            }
        }
        
    }
    /// <summary>
    /// Funcion para cambiar el color de un boton
    /// </summary>
    /// <param name="btn">boton a modificar</param>
    /// <param name="selectedColor">color deseado</param>
    private void changeButtonColor(Button btn, Color selectedColor)
    {            
        ColorBlock btnColor = btn.colors;
        btnColor.normalColor = selectedColor;   
        btnColor.selectedColor = selectedColor; 
        btn.colors = btnColor;            
    }
    
    IEnumerator tiempoDeEspera(float time)
    {         
        yield return new WaitForSeconds(time);
        //SceneManager.LoadScene(1);  
        ResetControls();
        BuildInterfaz(); 
    }

    private void ChangeScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName,LoadSceneMode.Single);
    }

    private void ResetControls()
    {
        respuestasQueYaSalieron = string.Empty;
        changeButtonColor(btnRespuesta1,Color.white);
        changeButtonColor(btnRespuesta2,Color.white);
        changeButtonColor(btnRespuesta3,Color.white);
        changeButtonColor(btnRespuesta4,Color.white);
        BloqueaActivaBotones(btnRespuesta1,true);
        BloqueaActivaBotones(btnRespuesta2,true);
        BloqueaActivaBotones(btnRespuesta3,true);
        BloqueaActivaBotones(btnRespuesta4,true);
    }

    #endregion

}
