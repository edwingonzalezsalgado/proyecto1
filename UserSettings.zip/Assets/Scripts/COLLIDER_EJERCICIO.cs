using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class COLLIDER_EJERCICIO : MonoBehaviour
{
    public TextMeshProUGUI lblPuntos;    
    public TextMeshProUGUI lblEnd;    
    public TextMeshProUGUI lblLose;    
    private void OnCollisionEnter2D(Collision2D other) {
        //Debug.Log("OnCollisionEnter2D.name: "+other.gameObject.name);
        //Debug.Log("OnCollisionEnter2D.active: "+other.gameObject.active.ToString());
        //Debug.Log("tag: "+other.gameObject.tag);

        if(other.gameObject.name.Contains("Ladrillo"))
        {
            int puntos = int.Parse(lblPuntos.text);
            puntos++;
            
            //switch(other.gameObject.tag)
            //{
              //  case "verde":
                //{
                  //  other.gameObject.tag = "rojo";
                    //puntos+=10;
                  //  break;
                //}
                
            //}
            
            if(puntos<=480)
            {            
                lblPuntos.text = puntos.ToString();
                other.gameObject.SetActive(false);
            }
            if(puntos == 480) {
                lblEnd.text = "GANASTE";
            }
        }
        if(other.gameObject.name.Contains("piso"))
        {
            
            //lblLose.text = "PERDISTE";
           
        }
    }

    private void OnTriggerEnter2D(Collider2D other) {
        Debug.Log("OnTriggerEnter2D: "+other.gameObject.name);
    }
}
