using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class EJERCICIO1NUMEROS : MonoBehaviour
{
   public TMP_InputField  numero1;
   public TMP_InputField  numero2;
   public TextMeshProUGUI numeroAcalcular;
   public TextMeshProUGUI txtMensaje;
   List<string> m_DropOptions = new List<string> { "suma", "resta"};
   public TMP_Dropdown m_Dropdown;
   //Constructor
    public EJERCICIO1NUMEROS() {
        
    }
    void Start()
    {
        btnReset_onClick();        
    }

    public void consola(string msj){
        Debug.Log(msj);
    }

   int getRandomNumber()
    {        
        int number = Random.Range(1, 10);

        return number;
    }

    public void btnVerificar_onclick()
    {

        if((numero1.text == "")||(numero2.text=="")||(m_Dropdown.value==0))
        {
            txtMensaje.text = "Revise valores y tipo de operacion";
            return;
        }
        txtMensaje.text = "";
        consola("numero1: " +numero1.text);
        consola("numero2: " +numero2.text);
        int num1 = int.Parse(numero1.text);
        int num2 = int.Parse(numero2.text);
        int numCalcular = int.Parse(numeroAcalcular.text);
        int tipoOperacion = m_Dropdown.value;
        validaNumeros(num1, num2, numCalcular, tipoOperacion);
    }
    public void btnReset_onClick () {
        numeroAcalcular.text = getRandomNumber().ToString();
        consola("Numero a calcular: "+numeroAcalcular.text);
        numero1.text = "";
        numero2.text = "";
        txtMensaje.text = "";
        //m_Dropdown.value = 0;
    }

    public void ddTipoOperacion_onChange () {
        consola("Operacion seleccionada: "+m_Dropdown.value.ToString());
    }

    public void validaNumeros(int num1,int num2,int numCalcular,int tipoOperacion)
    {
        int res = 0;

            switch (tipoOperacion) {
                case 1://suma
                {
                    res = num1 + num2;                    
                    break;
                }
                case 2://resta
                {
                    res = num1 - num2;
                    break;
                }
            }
        if(res==numCalcular) 
            txtMensaje.text = "Muy bien ";
        else
            txtMensaje.text = "Intentalo nuevamente";
    }
}
