using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arreglos : MonoBehaviour
{
    public string[] arrNombres = {"edwin", "profe", "compañeros", "ucamp"};
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("primer jugador: " + arrNombres[0]);
        Debug.Log("ultimo jugador: " + arrNombres[(arrNombres.Length-1)]);
        int jugadorRandom = getRandomNumber();
        Debug.Log("Random: " + jugadorRandom.ToString());        
        Debug.Log("jugador random: " + arrNombres[jugadorRandom]);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    int getRandomNumber()
    {        
        int number = Random.Range(1, arrNombres.Length);

        return number;
    }
}
